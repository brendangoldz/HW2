from log_regression import LogisticalRegression()

import numpy as np 

class LogisticalRegression():
     
    def __init__(self.data):
        self.data = data
        self.TERMINATION_VALUE = 2^-32
        self.ITERATIONS = 10000
        self.LEARNING_RATE = 0.001
        
    def calculate(self, data):
        for i in range(3):
            lr = LogisticalRegression(self.TERMINATION_VALUE, self.ITERATIONS, self.LEARNING_RATE = 0.001)
        return weights, bias
    
    