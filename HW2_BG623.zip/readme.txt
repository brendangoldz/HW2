- Make sure Conda and Jupyter are installed to your classpath..
- Activate and Conda Install: Jupyter, Jupyter-Lab and any other dependencies needed for Jupyter
- Open folder in Jupyter Lab; Look how HW2_pt2.ipynb and HW2_pt3.ipnyb

For single class Logistical Regression:
- Open HW2_pt2.ipynb
- Restart and Run all Cells

For multi-class Logistical Regression:
- Open HW2_pt3.ipynb
- Restart and Run all Cells
